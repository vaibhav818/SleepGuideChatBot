"use client"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MoonStar, BarChart2, Headphones, Settings, LogOut } from "lucide-react"

export default function AppSidebar({ activeTab, setActiveTab }) {
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: MoonStar },
    { id: "sleep-tracking", label: "Sleep Tracking", icon: BarChart2 },
    { id: "relaxation", label: "Relaxation", icon: Headphones },
    { id: "settings", label: "Settings", icon: Settings },
  ]

  return (
    <Sidebar>
      <SidebarHeader className="flex flex-col items-center justify-center py-6">
        <div className="flex items-center space-x-2">
          <MoonStar className="h-8 w-8 text-purple-600" />
          <h1 className="text-xl font-bold">Slumber</h1>
        </div>
        <div className="mt-6 flex flex-col items-center">
          <Avatar className="h-16 w-16">
            <AvatarImage src="/placeholder.svg?height=64&width=64" alt="User" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
          <h2 className="mt-2 text-lg font-medium">Jane Doe</h2>
          <p className="text-sm text-muted-foreground">Sleep Score: 85</p>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.id}>
              <SidebarMenuButton isActive={activeTab === item.id} onClick={() => setActiveTab(item.id)}>
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <SidebarMenuButton>
          <LogOut className="h-5 w-5" />
          <span>Sign Out</span>
        </SidebarMenuButton>
        <div className="mt-4 text-xs text-center text-muted-foreground">
          <p>Slumber AI v1.0.0</p>
          <p>© 2025 Slumber Inc.</p>
        </div>
      </SidebarFooter>
      <div className="md:hidden absolute top-4 right-4">
        <SidebarTrigger />
      </div>
    </Sidebar>
  )
}

