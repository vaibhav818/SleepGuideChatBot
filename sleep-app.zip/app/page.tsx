import type { Metadata } from "next"
import DashboardPage from "@/components/dashboard-page"

export const metadata: Metadata = {
  title: "Slumber - AI Sleep Optimization",
  description: "Personalized sleep recommendations and tracking powered by AI",
}

export default function Home() {
  return <DashboardPage />
}

