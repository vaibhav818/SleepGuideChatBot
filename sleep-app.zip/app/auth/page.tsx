import type { Metadata } from "next"
import AuthInterface from "@/components/auth-interface"

export const metadata: Metadata = {
  title: "Sign In - Slumber",
  description: "Sign in to your Slumber account",
}

export default function AuthPage() {
  return <AuthInterface />
}

