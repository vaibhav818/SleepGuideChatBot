import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import jwt from "jsonwebtoken"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function withAuth(request: Request, handler: (userId: string, request: Request) => Promise<NextResponse>) {
  try {
    // Get token from cookies
    const token = cookies().get("auth-token")?.value

    if (!token) {
      return NextResponse.json({ message: "Authentication required" }, { status: 401 })
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "fallback-secret-do-not-use-in-production") as {
      userId: string
    }

    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
    })

    if (!user) {
      return NextResponse.json({ message: "User not found" }, { status: 401 })
    }

    // Call the handler with the authenticated user ID
    return await handler(decoded.userId, request)
  } catch (error) {
    console.error("Authentication error:", error)
    return NextResponse.json({ message: "Authentication failed" }, { status: 401 })
  } finally {
    await prisma.$disconnect()
  }
}

