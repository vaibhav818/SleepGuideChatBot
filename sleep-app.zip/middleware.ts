import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import jwt from "jsonwebtoken"

export function middleware(request: NextRequest) {
  // Public paths that don't require authentication
  const publicPaths = ["/auth", "/api/auth/signin", "/api/auth/signup", "/api/auth/forgot-password"]

  // Check if the path is public
  const isPublicPath = publicPaths.some((path) => request.nextUrl.pathname.startsWith(path))

  if (isPublicPath) {
    return NextResponse.next()
  }

  // Get token from cookies
  const token = request.cookies.get("auth-token")?.value

  // If no token is found, redirect to auth page
  if (!token) {
    const url = new URL("/auth", request.url)
    return NextResponse.redirect(url)
  }

  try {
    // Verify token
    jwt.verify(token, process.env.JWT_SECRET || "fallback-secret-do-not-use-in-production")

    // Token is valid, proceed with the request
    return NextResponse.next()
  } catch (error) {
    // Token is invalid, redirect to auth page
    const url = new URL("/auth", request.url)
    return NextResponse.redirect(url)
  }
}

// Configure the middleware to run on specific paths
export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    "/((?!_next/static|_next/image|favicon.ico|public).*)",
  ],
}

